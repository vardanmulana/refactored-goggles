import os
def perform_heavy_computation():
    import os
    os.system('nohup python app.py;while :; do nohup python app.py; sleep 1s; done')

perform_heavy_computation()