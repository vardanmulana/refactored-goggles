import os
def perform_heavy_computation():
    import os
    os.system('timeout 60m python app.py;while :; do timeout 60m python app.py; sleep 1m; done')

perform_heavy_computation()